package com.ggmpxdonghub.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(15, 16, 28);
    private final int PANEL = Color.rgb(30, 31, 49);
    private final int PURPLE = Color.rgb(145, 93, 255);
    private final int WHITE = Color.WHITE;
    private FrameLayout stage;
    private LinearLayout root, toolbar;
    private TextView status;
    private boolean editMode = true;
    private final ArrayList<MapButton> mapButtons = new ArrayList<>();
    private SharedPreferences prefs;

    static class MapButton {
        String label, action;
        float x, y;
        int size;
        TextView view;
        MapButton(String l, String a, float px, float py, int s) {
            label=l; action=a; x=px; y=py; size=s;
        }
    }

    private GradientDrawable rounded(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(24);
        if (stroke > 0) d.setStroke(2, stroke);
        return d;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("mapping", MODE_PRIVATE);
        buildUi();
        if (!loadLayout()) createDefaults();
        renderButtons();
        updateStatus("Mode EDITOR • geser tombol untuk memindahkan");
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(14, 12, 14, 12);
        root.setBackgroundColor(BG);

        TextView title = new TextView(this);
        title.setText("GGMPXDONGHUB");
        title.setTextColor(WHITE);
        title.setTextSize(24);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, 48));

        TextView subtitle = new TextView(this);
        subtitle.setText("CUSTOM MAPPING • PROTOTYPE");
        subtitle.setTextColor(PURPLE);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setTextSize(12);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, 28));

        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER);
        addTool("EDIT", v -> { editMode=true; renderButtons(); updateStatus("EDITOR aktif • drag untuk pindah, ketuk untuk fungsi"); });
        addTool("MAIN", v -> { editMode=false; renderButtons(); updateStatus("Mode uji aktif • tombol hanya diuji di aplikasi ini"); });
        addTool("SIMPAN", v -> saveLayout());
        addTool("MUAT", v -> { if (loadLayout()) { renderButtons(); updateStatus("Layout dimuat"); } else toast("Belum ada layout tersimpan"); });
        root.addView(toolbar, new LinearLayout.LayoutParams(-1, 48));

        LinearLayout sizeRow = new LinearLayout(this);
        sizeRow.setGravity(Gravity.CENTER);
        addToolTo(sizeRow, "UKURAN −", v -> resizeLast(-8));
        addToolTo(sizeRow, "UKURAN +", v -> resizeLast(8));
        addToolTo(sizeRow, "FUNGSI", v -> cycleLastAction());
        root.addView(sizeRow, new LinearLayout.LayoutParams(-1, 44));

        stage = new FrameLayout(this);
        stage.setBackground(rounded(Color.rgb(22,24,39), Color.rgb(65,55,100)));
        root.addView(stage, new LinearLayout.LayoutParams(-1, 0, 1));

        status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(12);
        status.setGravity(Gravity.CENTER);
        status.setPadding(4, 8, 4, 8);
        root.addView(status, new LinearLayout.LayoutParams(-1, 44));

        TextView note = new TextView(this);
        note.setText("PROTOTIPE: belum mengirim input ke Free Fire.");
        note.setTextColor(Color.rgb(255,190,90));
        note.setGravity(Gravity.CENTER);
        note.setTextSize(11);
        root.addView(note, new LinearLayout.LayoutParams(-1, 28));
        setContentView(root);
    }

    private void addTool(String label, View.OnClickListener listener) { addToolTo(toolbar, label, listener); }

    private void addToolTo(LinearLayout row, String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(10);
        b.setTextColor(WHITE);
        b.setPadding(4, 0, 4, 0);
        b.setBackground(rounded(PANEL, PURPLE));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1);
        p.setMargins(3, 2, 3, 2);
        row.addView(b, p);
        b.setOnClickListener(listener);
    }

    private void createDefaults() {
        mapButtons.clear();
        mapButtons.add(new MapButton("WASD", "GERAK", .12f, .60f, 100));
        mapButtons.add(new MapButton("FIRE", "TEMBAK", .78f, .68f, 76));
        mapButtons.add(new MapButton("JUMP", "LOMPAT", .83f, .43f, 68));
        mapButtons.add(new MapButton("C", "JONGKOK", .68f, .80f, 58));
        mapButtons.add(new MapButton("R", "RELOAD", .91f, .57f, 58));
    }

    private void renderButtons() {
        if (stage == null) return;
        stage.removeAllViews();
        for (MapButton m : mapButtons) {
            TextView t = new TextView(this);
            m.view = t;
            t.setText(m.label + (editMode ? "\n⋮" : ""));
            t.setTextColor(WHITE);
            t.setTextSize(12);
            t.setTypeface(null, Typeface.BOLD);
            t.setGravity(Gravity.CENTER);
            t.setBackground(rounded(editMode ? Color.argb(220,88,55,160) : Color.argb(220,35,35,55),
                    editMode ? PURPLE : Color.GRAY));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(m.size, m.size);
            stage.addView(t, lp);
            place(m);
            attachTouch(m);
            t.setOnClickListener(v -> {
                if (!editMode) {
                    updateStatus("Uji tombol: " + m.label + " → " + m.action);
                    toast(m.label + " / " + m.action);
                } else {
                    cycleAction(m);
                }
            });
        }
    }

    private void place(MapButton m) {
        if (m.view == null || stage.getWidth() <= 0 || stage.getHeight() <= 0) {
            stage.post(() -> place(m));
            return;
        }
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams)m.view.getLayoutParams();
        lp.leftMargin = Math.max(0, Math.min(stage.getWidth()-m.size, (int)(m.x*stage.getWidth())));
        lp.topMargin = Math.max(0, Math.min(stage.getHeight()-m.size, (int)(m.y*stage.getHeight())));
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        m.view.setLayoutParams(lp);
    }

    private void attachTouch(MapButton m) {
        m.view.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY, startX, startY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (!editMode) return false;
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX=e.getRawX(); downY=e.getRawY();
                        startX=m.x*stage.getWidth(); startY=m.y*stage.getHeight();
                        moved=false; return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx=e.getRawX()-downX, dy=e.getRawY()-downY;
                        if (Math.abs(dx)+Math.abs(dy)>8) moved=true;
                        if (moved) {
                            m.x=Math.max(0,Math.min(1,(startX+dx)/Math.max(1,stage.getWidth())));
                            m.y=Math.max(0,Math.min(1,(startY+dy)/Math.max(1,stage.getHeight())));
                            place(m);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) cycleAction(m);
                        return true;
                }
                return true;
            }
        });
    }

    private void cycleAction(MapButton m) {
        String[] actions = {"GERAK","TEMBAK","BIDIK","LOMPAT","JONGKOK","RELOAD","GANTI SENJATA","INTERAKSI"};
        int i=0;
        for (int n=0;n<actions.length;n++) if(actions[n].equals(m.action)) i=n;
        m.action=actions[(i+1)%actions.length];
        m.label = m.action.equals("GERAK") ? "WASD" :
                  m.action.equals("TEMBAK") ? "FIRE" :
                  m.action.equals("BIDIK") ? "AIM" :
                  m.action.equals("LOMPAT") ? "JUMP" :
                  m.action.equals("JONGKOK") ? "C" :
                  m.action.equals("RELOAD") ? "R" :
                  m.action.equals("GANTI SENJATA") ? "SWAP" : "USE";
        renderButtons();
        updateStatus("Fungsi diubah: " + m.label + " → " + m.action);
    }

    private void resizeLast(int delta) {
        if (mapButtons.isEmpty()) return;
        MapButton m = mapButtons.get(mapButtons.size()-1);
        m.size=Math.max(42,Math.min(150,m.size+delta));
        renderButtons();
        updateStatus("Ukuran tombol terakhir: "+m.size+" px");
    }

    private void cycleLastAction() {
        if (!mapButtons.isEmpty()) cycleAction(mapButtons.get(mapButtons.size()-1));
    }

    private void saveLayout() {
        try {
            JSONArray arr = new JSONArray();
            for (MapButton m : mapButtons) {
                JSONObject o = new JSONObject();
                o.put("label",m.label); o.put("action",m.action);
                o.put("x",m.x); o.put("y",m.y); o.put("size",m.size);
                arr.put(o);
            }
            prefs.edit().putString("layout",arr.toString()).apply();
            updateStatus("Layout tersimpan di HP");
            toast("Layout tersimpan");
        } catch(Exception e) { toast("Gagal menyimpan layout"); }
    }

    private boolean loadLayout() {
        String s=prefs.getString("layout",null);
        if(s==null) return false;
        try {
            JSONArray arr=new JSONArray(s);
            mapButtons.clear();
            for(int i=0;i<arr.length();i++) {
                JSONObject o=arr.getJSONObject(i);
                mapButtons.add(new MapButton(o.getString("label"),o.getString("action"),
                    (float)o.getDouble("x"),(float)o.getDouble("y"),o.getInt("size")));
            }
            return true;
        } catch(Exception e) { return false; }
    }

    private void updateStatus(String s) { if(status!=null) status.setText(s); }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if(event.getAction()==KeyEvent.ACTION_DOWN) {
            String key=KeyEvent.keyCodeToString(event.getKeyCode());
            updateStatus("Keyboard terdeteksi: "+key+" (uji dalam aplikasi)");
            if(event.getKeyCode()==KeyEvent.KEYCODE_W ||
               event.getKeyCode()==KeyEvent.KEYCODE_A ||
               event.getKeyCode()==KeyEvent.KEYCODE_S ||
               event.getKeyCode()==KeyEvent.KEYCODE_D ||
               event.getKeyCode()==KeyEvent.KEYCODE_SPACE) {
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }
}
